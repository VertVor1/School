﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using classSchool;



namespace schoolUse
{
    class Program
    {
        public static Class1 cls = new Class1();
        static void Main(string[] args)
        {
            List<Mark> marks = new List<Mark>();

            List<Students> students = new List<Students>
            {
                new Students(2018,818,"Кулагин Антон Авдеевич"),
                new Students(2021,821,"Медведев Дмитрий Денисович"),
                new Students(2018,818,"Александров Кирилл Алексеевич"),
                new Students(2019,819,"Зуев Вадим Петрович"),
                new Students(2019,819,"Комаров Егор Вадимович"),
                new Students(2020,820,"Субботин Максим Андреевич"),
                new Students(2020,820,"Осипов Варлаам Николаеви"),
                new Students(2021,821,"Орлов Аркадий Тарасович"),
                new Students(2022,822,"Комиссаров Гарик Робертович"),
                new Students(2022,822,"Вертунов Максим Максимович"),
                new Students(2022,822,"Воронин Артём Александрович")
            };

            //Заполнение оценками
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.01.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("09.02.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("21.03.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("09.04.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("09.05.2022"), students));

            //Вывод всех оценок
            foreach (Mark m in marks)
            {
                Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.Estimation} - {m.student.fio}");
            }
            Console.WriteLine();

            //Вывод прогулов за месяцы
            foreach (int i in cls.GetCountTruancy(marks))
            {
                Console.WriteLine(i);

            }
            Console.WriteLine();

            //Вывод болезней за месяц
            foreach (int i in cls.GetCountDisease(marks))
            {
                Console.WriteLine(i);

            }
            Console.WriteLine();

            //Студенческие билеты студентов
            foreach(Students std in students)
            {
                Console.WriteLine(cls.GetStudNumber(std.year, std.group, std.fio));
            }
            Console.WriteLine();

            //Среднее арифметическое оценок в меньшую сторону
            Console.WriteLine(cls.MinAVG(new string[6]{ "3","2","3","б","п"," "}));
            Console.ReadKey();

        }
    }
}
